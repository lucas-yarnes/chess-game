package gamePieces;

import javax.swing.ImageIcon;

public class Bishop extends ChessPiece {
	
	 //purely testing purposes
	public Bishop() {}
	
	//create a rook with a starting (x, y) position
	public Bishop(int startX, int startY, String teamColor) {
		xPos = startX;
		yPos = startY;
		this.teamColor = teamColor;
		img = new ImageIcon("C:\\Users\\Lucas\\eclipse-workspace\\ChessGame\\src\\images\\bishop.png");
	}

	@Override
	public void movePiece(int xPos, int yPos) {

	}

	@Override
	public boolean isValidMove(int xDest, int yDest) {
		return false;
	}

	@Override
	public String toString() {
		return "Bishop";
	}

}
