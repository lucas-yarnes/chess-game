package gamePieces;

import javax.swing.ImageIcon;

public class Bishop extends ChessPiece {
	
	 //purely testing purposes
	public Bishop() {}
	
	//create a rook with a starting (x, y) position
	public Bishop(int startX, int startY, String teamColor) {
		xPos = startX;
		yPos = startY;
		this.teamColor = teamColor;
		img = new ImageIcon("C:\\Users\\Lucas\\eclipse-workspace\\ChessGame\\src\\images\\bishop.png");
	}

	@Override
	public boolean isValidMove(int xDest, int yDest) {
		boolean check = false;
		if (Math.abs(xDest - xPos) == Math.abs(yDest - yPos)) {
			check = true;
		}
		return check;
	}

	@Override
	public String toString() {
		return "Bishop";
	}

}
