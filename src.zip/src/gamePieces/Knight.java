package gamePieces;

import javax.swing.ImageIcon;

public class Knight extends ChessPiece {
	
	 //purely testing purposes
	public Knight() {}
	
	//create a rook with a starting (x, y) position
	public Knight(int startX, int startY, String teamColor) {
		xPos = startX;
		yPos = startY;
		this.teamColor = teamColor;
		img = new ImageIcon("C:\\Users\\Lucas\\eclipse-workspace\\ChessGame\\src\\images\\knight.png");
	}

	@Override
	public boolean isValidMove(int xDest, int yDest) {
		boolean check = false;
		if ((xDest == xPos + 2 || xDest == xPos - 2) && (yDest == yPos + 1 || yDest == yPos - 1)) {
			check = true;
		}
		if ((xDest == xPos + 1 || xDest == xPos - 1) && (yDest == yPos + 2 || yDest == yPos - 2)) {
			check = true;
		}
		return check;
	}

	@Override
	public String toString() {
		return "Knight";
	}

}
