package gamePieces;

import javax.swing.ImageIcon;

public class Queen extends ChessPiece {
	
	 //purely testing purposes
	public Queen() {}
	
	//create a rook with a starting (x, y) position
	public Queen(int startX, int startY, String teamColor) {
		xPos = startX;
		yPos = startY;
		this.teamColor = teamColor;
		img = new ImageIcon("C:\\Users\\Lucas\\eclipse-workspace\\ChessGame\\src\\images\\queen.png");
	}

	@Override
	public boolean isValidMove(int xDest, int yDest) {
		boolean check = false;
		if (Math.abs(xDest - xPos) == Math.abs(yDest - yPos)) {
			check = true;
		}
		if (xPos != xDest && yPos == yDest) {
			check = true;
		}
		if (xPos == xDest && yPos != yDest) {
			check = true;
		}
		return check;
	}

	@Override
	public String toString() {
		return "Queen";
	}

}
