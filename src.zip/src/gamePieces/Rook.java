package gamePieces;

import javax.swing.ImageIcon;

public class Rook extends ChessPiece {
	
	 //purely testing purposes
	public Rook() {}
	
	//create a rook with a starting (x, y) position
	public Rook(int startX, int startY, String teamColor) {
		xPos = startX;
		yPos = startY;
		this.teamColor = teamColor;
		img = new ImageIcon("C:\\Users\\Lucas\\eclipse-workspace\\ChessGame\\src\\images\\rook.png");
	}

	@Override
	public boolean isValidMove(int xDest, int yDest) {
		boolean check = false;
		if (xPos != xDest && yPos == yDest) {
			check = true;
		}
		if (xPos == xDest && yPos != yDest) {
			check = true;
		}
		return check;
	}

	@Override
	public String toString() {
		return "Rook";
	}

}
