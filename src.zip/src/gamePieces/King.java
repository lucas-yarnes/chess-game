package gamePieces;

import javax.swing.ImageIcon;

public class King extends ChessPiece {
	
	 //purely testing purposes
	public King() {}
	
	//create a rook with a starting (x, y) position
	public King(int startX, int startY, String teamColor) {
		xPos = startX;
		yPos = startY;
		this.teamColor = teamColor;
		img = new ImageIcon("C:\\Users\\Lucas\\eclipse-workspace\\ChessGame\\src\\images\\king.png");
	}

	@Override
	public boolean isValidMove(int xDest, int yDest) {
		boolean check = false;
		if ((xDest == xPos + 1 || xDest == xPos - 1 || xDest == xPos) && (yDest == yPos + 1 || yDest == yPos - 1 || yDest == yPos)) {
			check = true;
		}
		return check;
	}

	@Override
	public String toString() {
		return "King";
	}

}
