package main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class TileListener extends JButton implements ActionListener {
	
	private static int count;
	
	public void actionPerformed(ActionEvent e) {
		count++;
		if (count == 1) {
			int selectedX = Integer.parseInt(((JButton)e.getSource()).getName().substring(3, 4));
			int selectedY = Integer.parseInt(((JButton)e.getSource()).getName().substring(0, 1));
			System.out.println(selectedX + " " + selectedY);
			Board.setSelectedPos(selectedX, selectedY, count);
		}
		else if (count == 2) {
			int selectedX = Integer.parseInt(((JButton)e.getSource()).getName().substring(3, 4));
			int selectedY = Integer.parseInt(((JButton)e.getSource()).getName().substring(0, 1));
			System.out.println(selectedX + " " + selectedY);
			Board.setSelectedPos(selectedX, selectedY, count);
			count = 0;
			
		}
		
	}
	
}
